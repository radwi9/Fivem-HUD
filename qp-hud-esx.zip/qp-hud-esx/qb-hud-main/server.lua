local ESX = exports['es_extended']:getSharedObject()

-- دستورات جدید
RegisterCommand('cash', function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        local cashamount = xPlayer.getMoney()
        TriggerClientEvent('hud:client:ShowAccounts', source, 'cash', cashamount)
    else
        print("Error: xPlayer is nil")
    end
end, false)

RegisterCommand('bank', function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        local bankamount = xPlayer.getAccount('bank').money
        TriggerClientEvent('hud:client:ShowAccounts', source, 'bank', bankamount)
    else
        print("Error: xPlayer is nil")
    end
end, false)

RegisterCommand('dev', function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer and xPlayer.getGroup() == 'admin' then
        TriggerClientEvent('qb-admin:client:ToggleDevmode', source)
    else
        TriggerClientEvent('esx:showNotification', source, 'You are not authorized to use this command!')
    end
end, false)

-- رویدادها برای استرس
RegisterNetEvent('hud:server:GainStress', function(amount)
    if Config.DisableStress then return end
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    local job = xPlayer.job.name
    local jobType = xPlayer.job.type
    local newStress

    if Config.WhitelistedJobs[jobType] or Config.WhitelistedJobs[job] then return end

    local metadata = xPlayer.get('metadata') or {}
    if not metadata.stress then
        metadata.stress = 0
    end

    newStress = metadata.stress + amount
    if newStress <= 0 then newStress = 0 end
    if newStress > 100 then newStress = 100 end

    xPlayer.set('metadata', { stress = newStress })
    TriggerClientEvent('hud:client:UpdateStress', src, newStress)
    TriggerClientEvent('esx:showNotification', src, Lang:t('notify.stress_gain'))
end)

RegisterNetEvent('hud:server:RelieveStress', function(amount)
    if Config.DisableStress then return end
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    local newStress
    local metadata = xPlayer.get('metadata') or {}
    if not metadata.stress then
        metadata.stress = 0
    end

    newStress = metadata.stress - amount
    if newStress <= 0 then newStress = 0 end
    if newStress > 100 then newStress = 100 end

    xPlayer.set('metadata', { stress = newStress })
    TriggerClientEvent('hud:client:UpdateStress', src, newStress)
    TriggerClientEvent('esx:showNotification', src, Lang:t('notify.stress_removed'))
end)

-- Callback برای منو
ESX.RegisterServerCallback('hud:server:getMenu', function(source, cb)
    cb(Config.Menu)
end)
